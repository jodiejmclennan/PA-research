#!/usr/bin/env python
import site
import setuptools

# PEP517 workaround
site.ENABLE_USER_SITE = True

setuptools.setup()
