# this file makes importlib.resources work
